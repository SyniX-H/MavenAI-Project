#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState


class PickPlaceNode(Node):
    def __init__(self):
        super().__init__('pick_place_node')

        self.joint_pub = self.create_publisher(
            JointState,
            '/joint_commands',
            10
        )

        self.joint_sub = self.create_subscription(
            JointState,
            '/joint_states',
            self.joint_state_callback,
            10
        )

        self.timer = self.create_timer(0.1, self.control_loop)

        self.current_joints = [0.0] * 6
        self.target_joints = [0.0] * 6
        self.state = 'idle'
        self.get_logger().info('Pick and Place Node Started')

    def joint_state_callback(self, msg):
        if len(msg.position) >= 6:
            self.current_joints = list(msg.position[:6])

    def control_loop(self):
        if self.state == 'idle':
            self.target_joints = [0.5, -1.0, 1.5, -0.5, -1.57, 0.0]
            self.state = 'moving_to_grasp'

        elif self.state == 'moving_to_grasp':
            if self.joints_reached(self.target_joints):
                self.get_logger().info('Reached grasp position')
                self.state = 'grasping'

        elif self.state == 'grasping':
            self.get_logger().info('Grasping object')
            self.state = 'moving_to_place'
            self.target_joints = [0.0, -1.2, 1.8, -0.6, -1.57, 0.0]

        elif self.state == 'moving_to_place':
            if self.joints_reached(self.target_joints):
                self.get_logger().info('Reached place position')
                self.state = 'complete'

        self.publish_joint_command()

    def publish_joint_command(self):
        msg = JointState()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.name = [f'joint_{i+1}' for i in range(6)]
        msg.position = self.target_joints
        self.joint_pub.publish(msg)

    def joints_reached(self, target, tolerance=0.01):
        for i in range(6):
            if abs(self.current_joints[i] - target[i]) > tolerance:
                return False
        return True


def main(args=None):
    rclpy.init(args=args)
    node = PickPlaceNode()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
