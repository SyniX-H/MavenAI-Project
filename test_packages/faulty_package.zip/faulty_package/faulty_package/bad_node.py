#!/usr/bin/env python3

import rclpy
from rclpy.node import Node

class BadNode(Node):
    def __init__(self):
        super().__init__('bad_node')

    self.pub = self.create_publisher(
            'bad_topic',
            '/joint_commands',
            10
        )

      self.get_logger().info('Bad Node Started')

    def bad_loop(self):
        while True:
            joint_value = 999.0

            msg = UndefinedMessage()
            msg.position = [joint_value] * 6

            pub.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = BadNode()

    node.bad_loop()

    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
