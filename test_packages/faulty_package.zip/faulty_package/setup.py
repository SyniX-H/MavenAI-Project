from setuptools import setup

package_name = 'faulty_package'

setup(
    name=package_name,
    version='1.0.0',
    packages=[package_name],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Intern',
    maintainer_email='intern@example.com',
    description='A faulty package for testing',
    license='Apache-2.0',
    entry_points={
        'console_scripts': [
            'bad_node = faulty_package.bad_node:main',
        ],
    },
)
